import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';
import { Job } from '../../src/types';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { resumeText, availableJobs } = req.body || {};

    if (!resumeText || typeof resumeText !== 'string' || resumeText.trim().length < 10) {
      return res.status(400).json({
        success: false,
        error: 'Please provide candidate resume or skills text.',
      });
    }

    const jobsToAnalyze: Job[] =
      Array.isArray(availableJobs) && availableJobs.length > 0 ? availableJobs : [];

    if (jobsToAnalyze.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No active job listings available to match against.',
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;

    if (apiKey) {
      const ai = new GoogleGenAI({ apiKey });
      const subset = jobsToAnalyze.slice(0, 30);

      const prompt = `You are an expert recruitment career counselor.
Analyze the following candidate resume/skills profile and find the top 5 most compatible job listings.

Candidate Profile:
"""
${resumeText.substring(0, 2000)}
"""

Available Job Listings:
${JSON.stringify(
  subset.map((j) => ({
    id: j.id,
    title: j.title,
    company: j.company,
    category: j.category,
    skills: j.skills,
    summary: j.summary.substring(0, 300),
  }))
)}

Respond ONLY with a valid JSON array:
[
  {
    "jobId": "string",
    "matchScore": 0,
    "matchReason": "string",
    "keyMatchingSkills": ["string"]
  }
]`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });

      const responseText = (response.text || '')
        .replace(/```json/g, '')
        .replace(/```/g, '')
        .trim();

      try {
        return res.json({ success: true, matches: JSON.parse(responseText) });
      } catch {
        console.warn('Gemini returned invalid JSON; using heuristic matcher.');
      }
    }

    const resumeLower = resumeText.toLowerCase();
    const candidateTerms = resumeLower.split(/\W+/).filter((term: string) => term.length > 3);

    const matches = jobsToAnalyze
      .slice(0, 50)
      .map((job) => {
        const jobText = (
          job.title + ' ' + job.category + ' ' + job.description + ' ' + job.skills.join(' ')
        ).toLowerCase();

        let score = 30;
        const matchingSkills: string[] = [];

        job.skills.forEach((skill) => {
          if (resumeLower.includes(skill.toLowerCase())) {
            score += 15;
            matchingSkills.push(skill);
          }
        });

        candidateTerms.forEach((term: string) => {
          if (jobText.includes(term)) score += 2;
        });

        score = Math.min(98, Math.max(45, score));

        return {
          jobId: job.id,
          matchScore: score,
          matchReason: `Matches experience in ${job.category} with skills in ${
            matchingSkills.join(', ') || job.title
          }.`,
          keyMatchingSkills:
            matchingSkills.length > 0 ? matchingSkills : [job.category, job.workMode],
        };
      })
      .sort((a, b) => b.matchScore - a.matchScore)
      .slice(0, 5);

    return res.json({
      success: true,
      matches,
      note: apiKey ? 'Heuristic fallback used' : 'Heuristic search',
    });
  } catch (error) {
    console.error('AI match error:', error);
    return res.status(500).json({
      success: false,
      error: 'Failed to process AI resume matching.',
    });
  }
}
