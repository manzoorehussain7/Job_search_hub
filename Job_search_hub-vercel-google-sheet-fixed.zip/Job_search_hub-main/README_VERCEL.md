# JobSearchHub — Vercel + Google Sheets

## Google Sheet setup

The jobs API reads the sheet as CSV. The Google Sheet must be publicly readable.

1. Open the Google Sheet.
2. Click **Share**.
3. Under **General access**, select **Anyone with the link**.
4. Set permission to **Viewer**.
5. Copy the Sheet ID from the URL:
   `https://docs.google.com/spreadsheets/d/SHEET_ID/edit`
6. In Vercel, add `GOOGLE_SHEET_ID` with that ID.
7. Also add `VITE_GOOGLE_SHEET_ID` with the same ID so the frontend shows the correct source.
8. Redeploy.

The first row of the sheet must contain column headers. Supported job columns include:
`Title`, `Description`, `Summary`, `Category`, `Source`, `Enclosure`.

## Vercel API

- `GET /api/jobs` — loads jobs from Google Sheets.
- `GET /api/jobs?force=true` — forces a fresh Google Sheet read.
- `GET /api/jobs?sheetId=...` — reads a selected sheet.
- `POST /api/jobs` — syncs a selected sheet.
- `POST /api/ai/match` — AI/heuristic job matching.

The previous `server.ts` listened on port 3000, which is not the correct deployment model for a Vercel Vite app. The API has been moved to Vercel serverless functions under `/api`.
