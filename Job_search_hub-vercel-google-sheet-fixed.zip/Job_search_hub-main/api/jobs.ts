import type { VercelRequest, VercelResponse } from '@vercel/node';
import {
  fetchJobsFromSheet,
  getCachedJobs,
  getSheetId,
  setCachedJobs,
} from '../src/server/jobs';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'GET' && req.method !== 'POST') {
    res.setHeader('Allow', 'GET, POST');
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const rawSheetId =
      req.method === 'POST'
        ? (req.body?.sheetId as string | undefined)
        : (req.query.sheetId as string | undefined);

    const sheetId = getSheetId(rawSheetId);
    const force = req.method === 'POST' || req.query.force === 'true';

    const cached = getCachedJobs(sheetId, force);
    if (cached) {
      return res.status(200).json({
        success: true,
        cached: true,
        sheetId,
        lastSynced: new Date(cached.timestamp).toISOString(),
        total: cached.jobs.length,
        jobs: cached.jobs,
      });
    }

    const jobs = await fetchJobsFromSheet(sheetId);
    const entry = setCachedJobs(sheetId, jobs);

    return res.status(200).json({
      success: true,
      cached: false,
      sheetId,
      lastSynced: new Date(entry.timestamp).toISOString(),
      total: jobs.length,
      jobs,
    });
  } catch (error: any) {
    console.error('Google Sheet sync error:', error);
    return res.status(500).json({
      success: false,
      error: error?.message || 'Could not load job listings from Google Sheet.',
    });
  }
}
