import Papa from 'papaparse';
import { normalizeJobRow } from '../../src/utils/parseJobs';
import { Job } from '../../src/types';

export const DEFAULT_SHEET_ID =
  process.env.GOOGLE_SHEET_ID ||
  '15We6ItLp14oyoqTjboXlXEGIrEnYyENAWreNuhin45o';

export interface CacheEntry {
  jobs: Job[];
  timestamp: number;
  sheetId: string;
}

let jobsCache: CacheEntry | null = null;
const CACHE_TTL_MS = 30 * 1000;

function cleanSheetId(value: string): string {
  const input = value.trim();
  const match = input.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
  return match?.[1] || input;
}

export function getSheetId(value?: string): string {
  return cleanSheetId(value || DEFAULT_SHEET_ID);
}

export async function fetchJobsFromSheet(sheetId: string): Promise<Job[]> {
  const urls = [
    `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`,
    `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv`,
  ];

  let lastError = '';

  for (const url of urls) {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; JobSearchHub/1.0)',
          Accept: 'text/csv,text/plain,*/*',
        },
      });

      const text = await response.text();

      if (!response.ok) {
        lastError = `Google returned HTTP ${response.status}`;
        continue;
      }

      if (/<html|<!doctype|accounts\.google\.com|sign in to continue/i.test(text.slice(0, 1000))) {
        lastError =
          'The Google Sheet is not publicly readable. Set General access to "Anyone with the link" as Viewer, or publish the sheet to the web.';
        continue;
      }

      const jobs = parseCsvToJobs(text);

      if (jobs.length === 0) {
        const parsed = Papa.parse<Record<string, string>>(text, {
          header: true,
          skipEmptyLines: true,
        });
        if (!parsed.meta.fields?.length) {
          lastError =
            'Google Sheet was reached, but no column headers were found. The first row must contain headers such as Title, Description, Category, Source, and Enclosure.';
          continue;
        }
      }

      return jobs;
    } catch (error: any) {
      lastError = error?.message || 'Network error while reading Google Sheet';
    }
  }

  throw new Error(
    lastError ||
      'Unable to read the Google Sheet. Make sure the sheet is public and the Sheet ID is correct.'
  );
}

function parseCsvToJobs(csvText: string): Job[] {
  const parsed = Papa.parse<Record<string, string>>(csvText, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  });

  if (parsed.errors?.length) {
    console.warn('Google Sheet CSV parse warnings:', parsed.errors.slice(0, 3));
  }

  if (!parsed.data?.length) return [];

  return parsed.data
    .filter((row) => Object.values(row).some((value) => String(value ?? '').trim()))
    .map((row, idx) => normalizeJobRow(row, idx));
}

export function getCachedJobs(sheetId: string, force = false): CacheEntry | null {
  if (
    !force &&
    jobsCache &&
    jobsCache.sheetId === sheetId &&
    Date.now() - jobsCache.timestamp < CACHE_TTL_MS
  ) {
    return jobsCache;
  }
  return null;
}

export function setCachedJobs(sheetId: string, jobs: Job[]): CacheEntry {
  jobsCache = {
    jobs,
    timestamp: Date.now(),
    sheetId,
  };
  return jobsCache;
}
